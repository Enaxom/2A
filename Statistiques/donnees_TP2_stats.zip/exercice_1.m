clear;
close all;

donnees;

% Affichage des donnees bruitees :
% A DECOMMENTER
% figure('Name','Estimation d''un cercle par maximum de vraisemblance','Position',[0.5*L,0.2*H,0.4*L,0.6*H]);
% axis equal;
% hold on;
% hx = xlabel('$x$','FontSize',20);
% set(hx,'Interpreter','Latex');
% hy = ylabel('$y$','FontSize',20);
% set(hy,'Interpreter','Latex');
% plot(xy_donnees_bruitees(1,:),xy_donnees_bruitees(2,:),'b*','MarkerSize',10,'LineWidth',2);
% axis(echelle);
% set(gca,'FontSize',20);

% Tirage aleatoire uniforme de C :
% A DECOMMENTER/COMPLETER
% nb_tirages = 1000;
% C_test = (taille-R_0)*(2*rand(2,nb_tirages)-1);
% arguments = [];
% for k = 1:nb_tirages
% 	x_test = ...
% 	y_test = ...
% 	somme_carres_residus = 0;
% 	for i = 1:n
% 		residu = ...;
% 		somme_carres_residus = somme_carres_residus+...
% 	end
% 	arguments = [arguments somme_carres_residus];
% end
% [argument_min,indice_min] = min(arguments);
% C_estime = ...;
% xy_points_cercle = [R_0*cos(theta_points_cercle) ; R_0*sin(theta_points_cercle)]+C_estime*ones(1,nb_points_cercle);
% plot([xy_points_cercle(1,:) xy_points_cercle(1,1)],[xy_points_cercle(2,:) xy_points_cercle(2,1)],'g-','LineWidth',3);
% legend(' Donnees bruitees',' Cercle estime','Location','Best');
