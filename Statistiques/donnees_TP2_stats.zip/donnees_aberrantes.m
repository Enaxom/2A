clear;
close all;
taille_ecran = get(0,'ScreenSize');
L = taille_ecran(3);
H = taille_ecran(4);

% Parametres du cercle :
R_0 = 5;
taille = 20;
echelle = [-taille taille -taille taille];
C = (taille-R_0)*(2*rand(2,1)-1);

% Fenetre d'affichage :
figure('Name','Affichage des donnees','Position',[0.1*L,0.2*H,0.4*L,0.6*H]);
axis equal;
hold on;
hx = xlabel('$x$','FontSize',20);
set(hx,'Interpreter','Latex');
hy = ylabel('$y$','FontSize',20);
set(hy,'Interpreter','Latex');
set(gca,'FontSize',20);

% Affichage du cercle :
nb_points_cercle = 100;
theta_points_cercle = 2*pi/nb_points_cercle:2*pi/nb_points_cercle:2*pi;
xy_points_cercle = [R_0*cos(theta_points_cercle) ; R_0*sin(theta_points_cercle)]+C*ones(1,nb_points_cercle);
plot([xy_points_cercle(1,:) xy_points_cercle(1,1)],[xy_points_cercle(2,:) xy_points_cercle(2,1)],'r-','LineWidth',3);

% Donnees bruitees :
n = 20;
sigma = 0.5;
rho_donnees_bruitees = R_0+sigma*randn(1,n);
theta_donnees_bruitees = 2*pi*rand(1,n);
xy_donnees_bruitees = C*ones(1,n)+[rho_donnees_bruitees.*cos(theta_donnees_bruitees) ;...
				rho_donnees_bruitees.*sin(theta_donnees_bruitees)];

% Donnees aberrantes :
p = 0.2;
nb_donnees_aberrantes = floor(p*n);
xy_donnees_bruitees(:,1:nb_donnees_aberrantes) = taille*(2*rand(2,nb_donnees_aberrantes)-1);

% Affichages :
plot(xy_donnees_bruitees(1,:),xy_donnees_bruitees(2,:),'b*','MarkerSize',10,'LineWidth',2);
axis(echelle);
legend(' Cercle',' Donnees bruitees','Location','Best');
