package itam;

import itam.tamasmview.AsmView;

import org.eclipse.jface.action.ICoolBarManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.ToolBarContributionItem;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

/**
 * An action bar advisor is responsible for creating, adding, and disposing of
 * the actions added to a workbench window. Each window will be populated with
 * new actions.
 */
public class ApplicationActionBarAdvisor extends ActionBarAdvisor {

	// Actions - important to allocate these only in makeActions, and then use
	// them
	// in the fill methods. This ensures that the actions aren't recreated
	// when fillActionBars is called with FILL_PROXY.
	private IWorkbenchAction exitAction;
	private IWorkbenchAction aboutAction;
	private IWorkbenchAction helpAction;
	// private IWorkbenchAction newWindowAction;
	private OpenViewAction openStackViewAction;
	private OpenViewAction openCodeViewAction;
	private OpenViewAction openConsoleViewAction;

	public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
		super(configurer);
	}

	protected void makeActions(final IWorkbenchWindow window) {
		exitAction = ActionFactory.QUIT.create(window);
		register(exitAction);
		helpAction = ActionFactory.HELP_CONTENTS.create(window);
		register(helpAction);
		aboutAction = ActionFactory.ABOUT.create(window);
		register(aboutAction);

		openStackViewAction = new OpenViewAction(window, Messages
				.getString("ApplicationActionBarAdvisor.Open_StackView"), //$NON-NLS-1$
				TamView.ID);
		register(openStackViewAction);
		openCodeViewAction = new OpenViewAction(window, Messages
				.getString("ApplicationActionBarAdvisor.Open_CodeView"), //$NON-NLS-1$
				AsmView.ID);
		register(openCodeViewAction);
		openConsoleViewAction = new OpenViewAction(window, Messages
				.getString("ApplicationActionBarAdvisor.Open_ConsoleView"), //$NON-NLS-1$
				"org.eclipse.ui.console.ConsoleView");
		register(openConsoleViewAction);
	}

	protected void fillMenuBar(IMenuManager menuBar) {
		MenuManager fileMenu = new MenuManager(Messages
				.getString("ApplicationActionBarAdvisor.File"), //$NON-NLS-1$
				IWorkbenchActionConstants.M_FILE);
		menuBar.add(fileMenu);
		MenuManager helpMenu = new MenuManager(Messages
				.getString("ApplicationActionBarAdvisor.Help"), //$NON-NLS-1$
				IWorkbenchActionConstants.M_HELP);
		menuBar.add(helpMenu);
		// File
		fileMenu.add(openCodeViewAction);
		fileMenu.add(openStackViewAction);
		fileMenu.add(openConsoleViewAction);
		fileMenu.add(new Separator());
		fileMenu.add(exitAction);
		// Help
		helpMenu.add(helpAction);
		helpMenu.add(aboutAction);
	}

	protected void fillCoolBar(ICoolBarManager coolBar) {
		IToolBarManager toolbar = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
		coolBar.add(new ToolBarContributionItem(toolbar, Messages
				.getString("ApplicationActionBarAdvisor.2"))); //$NON-NLS-1$
		toolbar.add(openCodeViewAction);
		toolbar.add(openStackViewAction);
		toolbar.add(openConsoleViewAction);
	}
}
