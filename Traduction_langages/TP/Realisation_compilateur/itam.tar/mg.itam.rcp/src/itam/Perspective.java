package itam;

import itam.tamasmview.AsmView;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

public class Perspective implements IPerspectiveFactory {

	public void createInitialLayout(IPageLayout layout) {
		String editorArea = layout.getEditorArea();
		layout.setEditorAreaVisible(false);

		// layout.addStandaloneView(TamView.ID, false, IPageLayout.LEFT, 0.25f,
		// editorArea);
		// layout.getViewLayout(TamView.ID).setCloseable(false);
		IFolderLayout cfolder = layout.createFolder(Messages
				.getString("Perspective.Console"), //$NON-NLS-1$
				IPageLayout.BOTTOM, 0.8f, editorArea);
//		cfolder.addPlaceholder("org.eclipse.ui.internal.console" + ":*"); //$NON-NLS-1$
		cfolder.addView("org.eclipse.ui.console.ConsoleView");
		// layout.addShowViewShortcut("org.eclipse.ui.console.ConsoleView");
		IFolderLayout afolder = layout.createFolder(Messages
				.getString("Perspective.Asm"), IPageLayout.LEFT, //$NON-NLS-1$
				0.45f, editorArea);
		afolder.addPlaceholder(AsmView.ID + ":*"); //$NON-NLS-1$
		afolder.addView(AsmView.ID);

		IFolderLayout shfolder = layout.createFolder(Messages
				.getString("Perspective.Stack_Heap"), //$NON-NLS-1$
				IPageLayout.RIGHT, 0.55f, editorArea);
		shfolder.addPlaceholder(TamView.ID + ":*"); //$NON-NLS-1$
		shfolder.addView(TamView.ID);
	}
}
