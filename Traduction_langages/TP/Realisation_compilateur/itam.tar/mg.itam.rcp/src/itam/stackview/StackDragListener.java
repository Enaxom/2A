package itam.stackview;

import itam.dataviewer.DataDragListener;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.swt.dnd.DragSourceEvent;

public class StackDragListener extends DataDragListener {

	public StackDragListener(StructuredViewer viewer) {
		super(viewer);
		// TODO Auto-generated constructor stub
	}

	public void dragSetData(DragSourceEvent event) {
		IStructuredSelection selection = (IStructuredSelection) viewer
				.getSelection();
		Stack[] datas = (Stack[]) selection.toList().toArray(
				new Stack[selection.size()]);
		if (StackTransfer.getInstance().isSupportedType(event.dataType)) {
			event.data = datas;
		}
	}

}
