package itam.stackview;

import itam.dataviewer.DataViewerDropAdapter;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.dnd.TransferData;

public class StackDropAdapter extends DataViewerDropAdapter {

	protected StackDropAdapter(TableViewer viewer) {
		super(viewer);
		// TODO Auto-generated constructor stub
	}

	public boolean validateDrop(Object target, int op, TransferData type) {
		return StackTransfer.getInstance().isSupportedType(type);
	}

	public boolean performDrop(Object data) {
		System.out.println("perform drop = " + data);

		Stack target = (Stack) getCurrentTarget();
		// il faut bien viser dans la table...
		System.out.println("Target = " + target);
		if (target == null)
			return false;
		ISelection sel = getViewer().getSelection();
		System.out.println("Sel Target = " + sel);
		String[] datas = (String[]) data;
		for (String d : datas) {
			System.out.println("File dropped = " + d);
		}
		((StackDataList) getViewer().getInput()).updateDbData(target);
		return true;
	}

}
