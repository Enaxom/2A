package itam.stackview;

import itam.dataviewer.AbstractDataViewer;
import itam.dataviewer.DataList;

import org.eclipse.jface.viewers.IBaseLabelProvider;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;

public class StackViewer extends AbstractDataViewer<Stack> {

	public StackViewer(Composite parent, DataList<Stack> dl) {
		super(parent, dl);
	}

	// @Override
	// protected void setupCellModifier() {
	// cellModifier = new StackCellModifier(this);
	// }
	//
	// @Override
	// protected void setupCellEditors(CellEditor[] editors) {
	// TextCellEditor textEditor = new TextCellEditor(table);
	// ((Text) textEditor.getControl()).setTextLimit(60);
	// for (int i = 0; i < 3; i++)
	// editors[i] = textEditor;
	// }

	@Override
	protected IBaseLabelProvider setupLabelProvider() {
		return new StackLabelProvider();
	}

	@Override
	protected void showInfo(int t, Shell shell) {
		// TODO Auto-generated method stub

	}

	// @Override
	// protected void setupDropAdapter() {
	// ops = DND.DROP_COPY | DND.DROP_MOVE;
	// dropTransfers = new Transfer[] { StackTransfer.getInstance() };
	// dropAdapter = new StackDropAdapter(tableViewer);
	// }

	@Override
	protected void setupDragListener() {
		ops = DND.DROP_COPY | DND.DROP_MOVE;
		dragTransfers = new Transfer[] { StackTransfer.getInstance() };
		dragListener = new StackDragListener(tableViewer);
	}

	// @Override
	// protected void setupDelListener() {
	// delTransfer = StackTransfer.getInstance();
	// delListener = new DelDropAdapter<Stack>(this, delTransfer);
	// }
}
