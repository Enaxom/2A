package itam.stackview;

import itam.dataviewer.AbstractCellModifier;
import itam.dataviewer.AbstractDataViewer;

import org.eclipse.swt.widgets.TableItem;

/**
 * This class implements an ICellModifierExtension An ICellModifierExtension is
 * called when the user modifes a cell in the tableViewer
 */

public class StackCellModifier extends AbstractCellModifier<Stack> {
	public StackCellModifier(AbstractDataViewer<Stack> tableViewer) {
		super(tableViewer);
	}

	public Object getValue(Object element, String property) {
		int columnIndex = columnNames.indexOf(property);

		Object result = null;
		Stack data = (Stack) element;
		switch (columnIndex) {
		case 0:
			result = "" + data.getAdresse();
			break;
		case 1:
			result = "" + data.getValeur();
			break;
		case 2:
			result = "" + data.isSt();
			break;
		case 3:
			result = "" + data.isLb();
			break;
		default:
			result = "";
		}
		return result;
	}

	/**
	 * @see org.eclipse.jface.viewers.ICellModifier#modify(java.lang.Object,
	 *      java.lang.String, java.lang.Object)
	 */
	public void modify(Object element, String property, Object value) {
		int columnIndex = columnNames.indexOf(property);
		TableItem item = (TableItem) element;
		Stack data = (Stack) item.getData();
		System.err.println("modify Stack = " + data);
		String valueString;
		switch (columnIndex) {
		case 0:
			valueString = ((String) value).trim();
			data.setAdresse(Integer.parseInt(valueString));
			break;
		case 1:
			valueString = ((String) value).trim();
			int adresse = Integer.parseInt(valueString);
			if (adresse != data.getValeur()) {
				data.setAdresse(adresse);
				tableViewer.getDataList().updateDbData(data);
			}
			break;
		case 2:
			valueString = ((String) value).trim();
			boolean st = Boolean.parseBoolean(valueString);
			if (st != data.isSt()) {
				data.setSt(st);
				tableViewer.getDataList().updateDbData(data);
			}
			break;
		case 3:
			valueString = ((String) value).trim();
			boolean lb = Boolean.parseBoolean(valueString);
			if (lb != data.isLb()) {
				data.setLb(lb);
				tableViewer.getDataList().updateDbData(data);
			}
			break;
		default:
		}
	}
}
