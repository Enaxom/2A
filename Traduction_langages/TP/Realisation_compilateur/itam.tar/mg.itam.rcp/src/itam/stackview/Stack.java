package itam.stackview;

import itam.dataviewer.Data;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Stack extends Data {
	private int adresse;

	private int valeur;

	private boolean st;

	private boolean lb;

	private String info;

	public Stack(int adresse, int valeur, boolean st, boolean lb, String info) {
		super("stack");
		this.adresse = adresse;
		this.valeur = valeur;
		this.st = st;
		this.lb = lb;
		this.info = info;
	}

	public Stack(DataInputStream dataIn) {
		super(dataIn);
		try {
			this.adresse = dataIn.readInt();
			this.valeur = dataIn.readInt();
			this.st = dataIn.readBoolean();
			this.lb = dataIn.readBoolean();
			this.info = dataIn.readUTF();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean equals(Object object) {
		if (!(object instanceof Stack))
			return false;
		if (this == object)
			return true;
		Stack data = ((Stack) object);
		return adresse == data.adresse && valeur == data.valeur;
	}

	public void writeData(DataOutputStream dataOut) throws IOException {
		super.writeData(dataOut);
		dataOut.writeInt(adresse);
		dataOut.writeInt(valeur);
		dataOut.writeBoolean(st);
		dataOut.writeBoolean(lb);
		dataOut.writeUTF(info);
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(adresse + ", " + valeur + " , " + st + ", " + lb + ", "
				+ info);
		return sb.toString();
	}

	public int getAdresse() {
		return adresse;
	}

	public void setAdresse(int adresse) {
		this.adresse = adresse;
	}

	public int getValeur() {
		return valeur;
	}

	public void setValeur(int valeur) {
		this.valeur = valeur;
	}

	public boolean isSt() {
		return st;
	}

	public void setSt(boolean st) {
		this.st = st;
	}

	public boolean isLb() {
		return lb;
	}

	public void setLb(boolean lb) {
		this.lb = lb;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

}
