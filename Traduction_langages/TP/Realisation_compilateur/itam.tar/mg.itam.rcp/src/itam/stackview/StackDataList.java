package itam.stackview;

import itam.dataviewer.DataList;

public class StackDataList extends DataList<Stack> {

	@Override
	public String[] getColumnNames() {
		return new String[] { "@", "Valeur", "ST", "LB", "Info" };
	}

	@Override
	public int[] getColumnTypes() {
		return null;
	}

	@Override
	public int[] getColumnWidths() {
		return new int[] { 60, 120, 40, 40, 120 };
	}

	@Override
	public int getColumnHeight() {
		return 100;
	}

}
