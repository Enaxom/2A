package itam.stackview;

import itam.Activator;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

/**
 * Label provider for the TaskViewer
 * 
 * @see org.eclipse.jface.viewers.LabelProvider
 */
public class StackLabelProvider extends LabelProvider implements
		ITableLabelProvider {

	// Names of icons used to represent checkboxes
	public static final String NO_IMAGE = "icons/no_image.gif";
	public static final String ST_IMAGE = "icons/st.gif";
	public static final String LB_IMAGE = "icons/lb.gif";

	private static final Image no_image = null;
	private static final Image st_image = Activator
			.getImageDescriptor(ST_IMAGE).createImage();
	private static final Image lb_image = Activator
			.getImageDescriptor(LB_IMAGE).createImage();

	/**
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnText(java.lang.Object,
	 *      int)
	 */
	public String getColumnText(Object element, int columnIndex) {
		String result = "";
		Stack data = (Stack) element;
		switch (columnIndex) {
		case 0:
			result = data.getAdresse() + "";
			break;
		case 1:
			result = data.getValeur() + "";
			break;
		case 4:
			result = data.getInfo() + "";
			break;
		default:
			break;
		}
		return result;
	}

	/**
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnImage(java.lang.Object,
	 *      int)
	 */
	public Image getColumnImage(Object element, int columnIndex) {
		Image result = no_image;
		Stack data = (Stack) element;
		switch (columnIndex) {
		case 2:
			if (data.isSt())
				result = st_image;
			break;
		case 3:
			if (data.isLb())
				result = lb_image;
			break;
		default:
			break;
		}
		return result;
	}
}
