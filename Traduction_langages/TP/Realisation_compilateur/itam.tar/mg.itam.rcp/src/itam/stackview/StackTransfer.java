package itam.stackview;

import itam.dataviewer.Data;
import itam.dataviewer.DataTransfer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Class for serializing datas to/from a byte array
 */
public class StackTransfer extends DataTransfer {
	private static DataTransfer instance = new StackTransfer();

	private static final String TYPE_NAME = "stack-transfer-format";

	private static final int TYPEID = registerType(TYPE_NAME);

	/**
	 * Returns the singleton data transfer instance.
	 */
	public static DataTransfer getInstance() {
		return instance;
	}

	/**
	 * Avoid explicit instantiation
	 */
	private StackTransfer() {
	}

	protected Data[] fromByteArray(byte[] bytes) {
		DataInputStream in = new DataInputStream(
				new ByteArrayInputStream(bytes));

		try {
			/* read number of datas */
			int n = in.readInt();
			/* read datas */
			Data[] datas = new Data[n];
			for (int i = 0; i < n; i++) {
				Data data = readData(in);
				if (data == null) {
					return null;
				}
				datas[i] = data;
			}
			return datas;
		} catch (IOException e) {
			return null;
		}
	}

	/*
	 * Method declared on Transfer.
	 */
	protected int[] getTypeIds() {
		return new int[] { TYPEID };
	}

	/*
	 * Method declared on Transfer.
	 */
	protected String[] getTypeNames() {
		return new String[] { TYPE_NAME };
	}

	/**
	 * Reads and returns a single data from the given stream.
	 */
	protected Data readData(DataInputStream dataIn) throws IOException {
		return new Stack(dataIn);
	}

	protected byte[] toByteArray(Data[] datas) {
		/**
		 * Transfer data is an array of datas. Serialized version is: (int)
		 * number of datas (Data) data 1 (Data) data 2 ... repeat for each
		 * subsequent data see writeData for the (Data) format.
		 */
		ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(byteOut);

		byte[] bytes = null;

		try {
			/* write number of markers */
			out.writeInt(datas.length);

			/* write markers */
			for (int i = 0; i < datas.length; i++) {
				writeData((Data) datas[i], out);
			}
			out.close();
			bytes = byteOut.toByteArray();
		} catch (IOException e) {
			// when in doubt send nothing
		}
		return bytes;
	}

	/**
	 * Writes the given data to the stream.
	 */
	protected void writeData(Data data, DataOutputStream dataOut)
			throws IOException {
		/**
		 * Data serialization to be defined in Data type
		 */
		data.writeData(dataOut);
	}
}