package itam.dataviewer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.eclipse.swt.dnd.ByteArrayTransfer;
import org.eclipse.swt.dnd.TransferData;

/**
 * Class for serializing datas to/from a byte array
 */
public abstract class DataTransfer extends ByteArrayTransfer {

	protected Data[] fromByteArray(byte[] bytes) {
		DataInputStream in = new DataInputStream(
				new ByteArrayInputStream(bytes));

		try {
			/* read number of datas */
			int n = in.readInt();
			/* read datas */
			Data[] datas = new Data[n];
			for (int i = 0; i < n; i++) {
				Data data = readData(in);
				if (data == null) {
					return null;
				}
				datas[i] = data;
			}
			return datas;
		} catch (IOException e) {
			return null;
		}
	}

	/*
	 * Method declared on Transfer.
	 */
	protected void javaToNative(Object object, TransferData transferData) {
		byte[] bytes = toByteArray((Data[]) object);
		if (bytes != null)
			super.javaToNative(bytes, transferData);
	}

	/*
	 * Method declared on Transfer.
	 */
	protected Object nativeToJava(TransferData transferData) {
		byte[] bytes = (byte[]) super.nativeToJava(transferData);
		return fromByteArray(bytes);
	}

	protected byte[] toByteArray(Data[] datas) {
		/**
		 * Transfer data is an array of datas. Serialized version is: (int)
		 * number of datas (Data) data 1 (Data) data 2 ... repeat for each
		 * subsequent data see writeData for the (Data) format.
		 */
		ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(byteOut);

		byte[] bytes = null;

		try {
			/* write number of markers */
			out.writeInt(datas.length);

			/* write markers */
			for (int i = 0; i < datas.length; i++) {
				writeData((Data) datas[i], out);
			}
			out.close();
			bytes = byteOut.toByteArray();
		} catch (IOException e) {
			// when in doubt send nothing
		}
		return bytes;
	}

	/**
	 * Writes the given data to the stream.
	 */
	protected void writeData(Data data, DataOutputStream dataOut)
			throws IOException {
		/**
		 * Data serialization to be defined in Data type
		 */
		data.writeData(dataOut);
	}

	abstract protected Data readData(DataInputStream dataIn) throws IOException;
}