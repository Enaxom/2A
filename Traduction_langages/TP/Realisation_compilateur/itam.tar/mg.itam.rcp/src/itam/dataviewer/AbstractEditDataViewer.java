package itam.dataviewer;

import itam.Activator;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.DropTarget;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;

public abstract class AbstractEditDataViewer<D extends Data> extends
		AbstractDataViewer<D> {
	Composite parent;

	private boolean editable = false;

	protected ICellModifierExtension cellModifier;

	protected Button add;

	protected Button update;

	protected DataViewerDropAdapter dropAdapter;

	protected Label del;

	protected DelDropAdapter<D> delListener = null;

	protected Transfer delTransfer = null;

	protected Transfer[] dropTransfers = null;

	/**
	 * @param parent
	 */
	public AbstractEditDataViewer(Composite parent, DataList<D> dl) {
		super(parent, dl);
	}

	/**
	 * Create the TableViewer
	 */
	protected void createTableViewer() {
		super.createTableViewer();
		// Create the cell editors
		CellEditor[] editors = new CellEditor[getColumnNames().length];
		// to be defined in a subclass
		setupCellEditors(editors);
		// Assign the cell editors to the viewer
		tableViewer.setCellEditors(editors);
		// Set the cell modifier for the viewer
		setupCellModifier();
		if (cellModifier != null)
			tableViewer.setCellModifier(cellModifier);
		// // Set the default sorter for the viewer
		// tableViewer.setSorter(new DataSorter(DataSorter.DESCRIPTION));
		setupDropAdapter();
		if (dropAdapter != null && dropTransfers != null)
			tableViewer.addDropSupport(ops, dropTransfers, dropAdapter);
	}

	private Image loadImage(Display display, String file) {
		return Activator.getImageDescriptor(file).createImage();
	}

	protected void createButtons(Composite parent) {
		update = new Button(parent, SWT.TOGGLE | SWT.CENTER);
		update.setToolTipText(Messages.AbstractDataViewer_Edit);
		update.setText(Messages.AbstractEditDataViewer_Edit);
		Image iedit = loadImage(update.getDisplay(), "icons/edit.gif"); //$NON-NLS-1$
		update.setImage(iedit);
		GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING);
		update.setLayoutData(gridData);
		update.addSelectionListener(new SelectionAdapter() {
			// Add a data to the DataList and refresh the view
			public void widgetSelected(SelectionEvent e) {
				if (update.getSelection()) {
					setEditable(true);
					update.setToolTipText(Messages.AbstractDataViewer_Consult);
				} else {
					setEditable(false);
					update.setToolTipText(Messages.AbstractDataViewer_Edit);
				}
			}
		});
		// Create and configure the "Add" button
		add = new Button(parent, SWT.PUSH | SWT.CENTER);
		add.setVisible(false);
		add.setText(Messages.AbstractEditDataViewer_Create);
		add.setToolTipText(Messages.AbstractDataViewer_Create);
		Image iadd = loadImage(add.getDisplay(), "icons/new.gif"); //$NON-NLS-1$
		add.setImage(iadd);

		gridData = new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING);
		add.setLayoutData(gridData);
		add.addSelectionListener(new SelectionAdapter() {
			// Add a data to the DataList and refresh the view
			public void widgetSelected(SelectionEvent e) {
				dataList.createDbData();
			}
		});

		del = new Label(parent, SWT.NONE | SWT.CENTER);
		del.setVisible(false);
		del.setText(Messages.AbstractEditDataViewer_Bin);
		Image idel = loadImage(del.getDisplay(), "icons/poubelle.gif"); //$NON-NLS-1$
		del.setImage(idel);
		gridData = new GridData(GridData.HORIZONTAL_ALIGN_END);
		del.setLayoutData(gridData);
		setupDelListener();
		if (delListener != null && delTransfer != null) {
			DropTarget dropTarget = new DropTarget(del, DND.DROP_COPY
					| DND.DROP_MOVE);
			dropTarget.setTransfer(new Transfer[] { delTransfer });
			dropTarget.addDropListener(delListener);
		}

		setEditable(false);
		super.createButtons(parent);
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
		if (dropAdapter != null)
			dropAdapter.setActive(editable);
		if (cellModifier != null)
			cellModifier.setEditable(editable);
		add.setVisible(editable);
		del.setVisible(editable);
	}

	public boolean isEditable() {
		return editable;
	}

	abstract protected void setupCellModifier();

	abstract protected void setupCellEditors(CellEditor[] editors);

	abstract protected void setupDropAdapter();

	protected abstract void setupDelListener();
}
