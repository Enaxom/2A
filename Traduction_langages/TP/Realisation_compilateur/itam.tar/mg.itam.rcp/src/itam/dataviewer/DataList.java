package itam.dataviewer;

import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

public abstract class DataList<D extends Data> {

	private final int COUNT = 10;

	private Vector<D> datas = new Vector<D>(COUNT);

	private Set<IDataListViewer<D>> changeListeners = new HashSet<IDataListViewer<D>>();

	public DataList() {
	}

	/**
	 * Return the collection of datas
	 */
	public Vector<D> getDatas() {
		return datas;
	}

	/**
	 * Add a new data to the collection of datas
	 */
	public void addData(D data) {
		datas.add(datas.size(), data);
		for (IDataListViewer<D> cl : changeListeners)
			cl.addData(data);
	}

	public void addData(int i, D data) {
		datas.add(i, data);
		for (IDataListViewer<D> cl : changeListeners)
			cl.addData(i, data);
	}

	/**
	 * @param data
	 */
	public void deleteData(D data) {
		datas.remove(data);
		for (IDataListViewer<D> cl : changeListeners)
			cl.deleteData(data);
	}

	/**
	 * @param data
	 */
	public void updateData(D data) {
		for (IDataListViewer<D> cl : changeListeners)
			cl.updateData(data);
	}

	public void clearDatas() {
		for (D data : datas)
			for (IDataListViewer<D> cl : changeListeners)
				cl.deleteData(data);
		datas.clear();
	}

	/**
	 * 
	 * 
	 * @param viewer
	 */
	public void removeChangeListener(IDataListViewer<D> viewer) {
		changeListeners.remove(viewer);
	}

	/**
	 * @param viewer
	 */
	public void addChangeListener(IDataListViewer<D> viewer) {
		changeListeners.add(viewer);
	}

	public void fillDbDatas() {
	}

	public void updateDbData(D data) {
	}

	public void deleteDbData(D data) {
	}

	public void createDbData() {
	}

	protected String toValue(String value) {
		if (value == null)
			return Messages.DataList_dbNULL;
		else
			return "\"" + value + "\""; //$NON-NLS-1$ //$NON-NLS-2$
	}

	abstract public String[] getColumnNames();

	abstract public int[] getColumnTypes();

	abstract public int[] getColumnWidths();

	abstract public int getColumnHeight();

}
