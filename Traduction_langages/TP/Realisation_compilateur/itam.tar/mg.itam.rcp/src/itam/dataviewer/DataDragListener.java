package itam.dataviewer;

import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.swt.dnd.DragSourceAdapter;
import org.eclipse.swt.dnd.DragSourceEvent;

/**
 * Supports dragging datas from a structured viewer.
 */
public abstract class DataDragListener extends DragSourceAdapter {
	protected StructuredViewer viewer;

	public DataDragListener(StructuredViewer viewer) {
		this.viewer = viewer;
	}

	/**
	 * Method declared on DragSourceListener
	 */
	public void dragFinished(DragSourceEvent event) {
		if (!event.doit)
			return;
		// // if the data was moved, remove it from the source viewer
		// if (event.detail == DND.DROP_MOVE) {
		// IStructuredSelection selection = (IStructuredSelection) viewer
		// .getSelection();
		// viewer.refresh();
		// }
	}

	/**
	 * Method declared on DragSourceListener
	 */
	public abstract void dragSetData(DragSourceEvent event);

	/**
	 * Method declared on DragSourceListener
	 */
	public void dragStart(DragSourceEvent event) {
		event.doit = !viewer.getSelection().isEmpty();
	}
}