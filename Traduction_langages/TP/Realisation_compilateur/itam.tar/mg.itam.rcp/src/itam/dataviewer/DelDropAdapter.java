package itam.dataviewer;

import org.eclipse.swt.dnd.DropTargetAdapter;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.Transfer;

public class DelDropAdapter<D extends Data> extends DropTargetAdapter {
	private Transfer transfer;

	private AbstractEditDataViewer<D> viewer;

	public DelDropAdapter(AbstractEditDataViewer<D> viewer, Transfer transfer) {
		this.viewer = viewer;
		this.transfer = transfer;
	}

	public void dragEnter(DropTargetEvent event) {
	}

	public void dragLeave(DropTargetEvent event) {
	}

	public void dragOperationChanged(DropTargetEvent event) {
	}

	public void dragOver(DropTargetEvent event) {
	}

	public void drop(DropTargetEvent event) {
		if (!viewer.isEditable())
			return;
		if (transfer.isSupportedType(event.currentDataType)) {
			D[] datas = (D[]) event.data;
			for (D data : datas) {
				((DataList<D>) viewer.getDataList()).deleteDbData(data);
			}
			// viewer.getTableViewer().refresh();
		}
	}

	public void dropAccept(DropTargetEvent event) {
	}

}
