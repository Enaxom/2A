/**
 * (c) Copyright Mirasol Op'nWorks Inc. 2002, 2003. 
 * http://www.opnworks.com
 * Created on Apr 2, 2003 by lgauthier@opnworks.com
 * 
 */

package itam.dataviewer;

import java.util.Arrays;
import java.util.List;

/**
 * This class implements an ICellModifierExtension An ICellModifierExtension is
 * called when the user modifes a cell in the tableViewer
 */

public abstract class AbstractCellModifier<D extends Data> implements
		ICellModifierExtension {
	protected AbstractDataViewer<D> tableViewer;

	protected List<String> columnNames;

	private boolean editable = true;;

	/**
	 * Constructor
	 * 
	 * @param LieuViewer
	 *            an instance of a LieuViewer
	 */
	public AbstractCellModifier(AbstractDataViewer<D> tableViewer) {
		super();
		this.tableViewer = (AbstractDataViewer<D>) tableViewer;
		columnNames = Arrays.asList(tableViewer.getColumnNames());
	}

	/**
	 * @see org.eclipse.jface.viewers.ICellModifier#canModify(java.lang.Object,
	 *      java.lang.String)
	 */
	public boolean canModify(Object element, String property) {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}
	/**
	 * @see org.eclipse.jface.viewers.ICellModifier#getValue(java.lang.Object,
	 *      java.lang.String)
	 */
}
