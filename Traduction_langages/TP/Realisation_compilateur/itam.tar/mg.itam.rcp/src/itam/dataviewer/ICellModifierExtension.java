package itam.dataviewer;

import org.eclipse.jface.viewers.ICellModifier;

public interface ICellModifierExtension extends ICellModifier {
	public void setEditable(boolean editable);
}
