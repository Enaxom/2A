package itam.dataviewer;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.ViewerDropAdapter;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.DropTargetEvent;

public abstract class DataViewerDropAdapter extends ViewerDropAdapter {

	private boolean active = false;

	protected DataViewerDropAdapter(TableViewer viewer) {
		super(viewer);

	}

	public void drop(DropTargetEvent event) {
		if (isActive()) {
			super.drop(event);
			((TableViewer) getViewer()).refresh();
		} else
			event.detail = DND.DROP_NONE;
	}

	private boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
}
