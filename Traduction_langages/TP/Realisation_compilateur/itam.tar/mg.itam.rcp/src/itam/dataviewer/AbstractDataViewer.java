package itam.dataviewer;

import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IBaseLabelProvider;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

public abstract class AbstractDataViewer<D extends Data> {
	Composite parent;

	protected Table table;

	protected TableViewer tableViewer;

	protected int ops = DND.DROP_COPY | DND.DROP_MOVE;

	protected Transfer[] dragTransfers = null;

	protected DataDragListener dragListener = null;

	protected DataList<D> dataList;

	protected SelectionListener selectionListener = null;;

	/**
	 * @param parent
	 */
	public AbstractDataViewer(Composite parent, DataList<D> dl) {
		this.parent = parent;
		dataList = dl;
		addChildControls(parent);
		tableViewer.setInput(dataList);
	}

	public void fill() {
		dataList.fillDbDatas();
	}

	private void addChildControls(Composite composite) {
		// Create a composite to hold the children
		GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_FILL
				| GridData.FILL_BOTH);
		composite.setLayoutData(gridData);

		// Set numColumns to 4 for the buttons
		GridLayout layout = new GridLayout(4, false);
		layout.marginWidth = 4;
		composite.setLayout(layout);
		// Create the table
		createTable(composite);
		// Create and setup the TableViewer
		createTableViewer();
		tableViewer.addDoubleClickListener(new IDoubleClickListener() {

			public void doubleClick(DoubleClickEvent arg0) {
				System.err.println("DC on row " + table.getSelectionIndex()); //$NON-NLS-1$
				// showInfo(table.getSelectionIndex(), table.getShell());
			}
		});
		tableViewer.setContentProvider(new ContentProvider());
		tableViewer.setLabelProvider(setupLabelProvider());
		// Add the buttons
		createButtons(composite);
	}

	abstract protected IBaseLabelProvider setupLabelProvider();

	/**
	 * Create the Table
	 */
	protected void createTable(Composite parent) {
		int style = SWT.MULTI | SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL
				| SWT.FULL_SELECTION | SWT.HIDE_SELECTION;
		table = new Table(parent, style);
		int height = getColumnHeight();
		GridData gridData = new GridData(GridData.FILL_BOTH);
		gridData.grabExcessVerticalSpace = true;
		gridData.horizontalSpan = 4;
		gridData.heightHint = height;
		table.setLayoutData(gridData);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		String[] cn = getColumnNames();
		int[] cw = getColumnWidths();
		for (int i = 0; i < cn.length; i++) {
			TableColumn column = new TableColumn(table, SWT.LEFT, i);
			column.setText(cn[i]);
			column.setWidth(cw[i]);
		}

	}

	public void setSelectionListener(SelectionListener listener) {
		table.addSelectionListener(listener);
	}

	protected void showItemInfo(int selectionIndex) {
	}

	abstract protected void showInfo(int t, Shell shell);

	/**
	 * Create the TableViewer
	 */
	protected void createTableViewer() {

		tableViewer = new TableViewer(table);
		tableViewer.setUseHashlookup(true);
		tableViewer.setColumnProperties(getColumnNames());
		setupDragListener();
		if (dragListener != null)
			tableViewer.addDragSupport(ops, dragTransfers, dragListener);

	}

	abstract protected void setupDragListener();

	/**
	 * InnerClass that acts as a proxy for the DataList providing content for
	 * the Table. It implements the IDataListViewer interface since it must
	 * register changeListeners with the DataList
	 */
	class ContentProvider implements IStructuredContentProvider,
			IDataListViewer<D> {
		public void inputChanged(Viewer v, Object oldInput, Object newInput) {
			if (newInput != null)
				((DataList<D>) newInput).addChangeListener(this);
			if (oldInput != null)
				((DataList<D>) oldInput).removeChangeListener(this);
		}

		public void dispose() {
			dataList.removeChangeListener(this);
		}

		// Return the datas as an array of Objects
		public Object[] getElements(Object parent) {
			return dataList.getDatas().toArray();
		}

		public void addData(D data) {
			tableViewer.add(data);
			tableViewer.reveal(data);
			tableViewer.refresh();
		}

		public void deleteData(D data) {
			tableViewer.remove(data);
			tableViewer.refresh();
		}

		public void updateData(D data) {
			tableViewer.update(data, null);
			tableViewer.refresh();
		}

		public void addData(int i, D data) {
			tableViewer.insert(data, i);
			tableViewer.reveal(data);
			tableViewer.refresh();
		}
	}

	protected void createButtons(Composite parent) {
	}

	/**
	 * Return the column names in a collection
	 * 
	 * @return List containing column names
	 */
	public String[] getColumnNames() {
		return dataList.getColumnNames();
	}

	public int[] getColumnWidths() {
		return dataList.getColumnWidths();
	}

	public int getColumnHeight() {
		return dataList.getColumnHeight();
	}

	/**
	 * @return currently selected item
	 */
	public ISelection getSelection() {
		return tableViewer.getSelection();
	}

	/**
	 * Return the DataList
	 */
	public DataList<D> getDataList() {
		return dataList;
	}

	/**
	 * Return the parent composite
	 */
	public Control getControl() {
		return table.getParent();
	}

	public Table getTable() {
		return table;
	}

	public TableViewer getTableViewer() {
		return tableViewer;
	}

}
