package itam.dataviewer;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "itam.dataviewer.messages"; //$NON-NLS-1$

	private Messages() {
	}

	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	public static String AbstractDataViewer_Consult;

	public static String AbstractDataViewer_Create;

	public static String AbstractDataViewer_Edit;

	public static String AbstractEditDataViewer_Bin;

	public static String AbstractEditDataViewer_Create;

	public static String AbstractEditDataViewer_Edit;

	public static String DataList_dbNULL;

	public static String AbstractDataViewer_Details;

	public static String AbstractDataViewer_Delete;

}
