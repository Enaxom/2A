package itam.dataviewer;

public interface IDataListViewer<D extends Data> {
	/**
	 * Update the view to reflect the fact that a data was added to the data
	 * list
	 * 
	 * @param data
	 */
	public void addData(D data);

	public void addData(int i, D data);

	/**
	 * Update the view to reflect the fact that a data was removed from the data
	 * list
	 * 
	 * @param data
	 */
	public void deleteData(D data);

	/**
	 * Update the view to reflect the fact that one of the datas was modified
	 * 
	 * @param data
	 */
	public void updateData(D data);

}
