package itam.tamasmview;

import itam.Activator;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

/**
 * Label provider for the TaskViewer
 * 
 * @see org.eclipse.jface.viewers.LabelProvider
 */
public class TamAsmLabelProvider extends LabelProvider implements
		ITableLabelProvider {

	// Names of icons used to represent checkboxes
	public static final String NO_IMAGE = "icons/no_image.gif";
	public static final String BP_IMAGE = "icons/brkp_obj.gif";
	public static final String CP_IMAGE = "icons/cp.gif";

	// private static final Image no_image = Activator
	// .getImageDescriptor(NO_IMAGE).createImage();
	private static final Image bp_image = Activator
			.getImageDescriptor(BP_IMAGE).createImage();
	private static final Image cp_image = Activator
			.getImageDescriptor(CP_IMAGE).createImage();
	private static final Image no_image = null;

	/**
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnText(java.lang.Object,
	 *      int)
	 */
	public String getColumnText(Object element, int columnIndex) {
		String result = "";
		TamAsm data = (TamAsm) element;
		switch (columnIndex) {
		case 0:
			result = data.getAdresse() + "";
			break;
		case 1:
			result = data.getEtiquette() + "";
			break;
		case 2:
			result = data.getInstruction() + "";
			break;
		default:
			break;
		}
		return result;
	}

	/**
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnImage(java.lang.Object,
	 *      int)
	 */
	public Image getColumnImage(Object element, int columnIndex) {
		Image result = no_image;
		TamAsm data = (TamAsm) element;
		switch (columnIndex) {
		case 3:
			if (data.isBp())
				result = bp_image;
			break;
		case 4:
			if (data.isCp())
				result = cp_image;
			break;
		default:
			break;
		}
		return result;
	}
}
