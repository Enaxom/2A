package itam.tamasmview;

import itam.dataviewer.DataList;

public class TamAsmDataList extends DataList<TamAsm> {

	@Override
	public String[] getColumnNames() {
		return new String[] { "# ", "Etiquette ", "Instruction", "BP", "CP" };
	}

	@Override
	public int[] getColumnTypes() {
		return null;
	}

	@Override
	public int[] getColumnWidths() {
		return new int[] { 60, 100, 180, 40, 40 };
	}

	@Override
	public int getColumnHeight() {
		// TODO Auto-generated method stub
		return 100;
	}

	public void fillDbDatas() {
	}

	public void updateDbData(TamAsm data) {
	}

	public void deleteDbData(TamAsm data) {
	}

	public void createDbData() {
	}

}
