package itam.tamasmview;

import itam.dataviewer.DataDragListener;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.swt.dnd.DragSourceEvent;

public class TamAsmDragListener extends DataDragListener {

	public TamAsmDragListener(StructuredViewer viewer) {
		super(viewer);
		// TODO Auto-generated constructor stub
	}

	public void dragSetData(DragSourceEvent event) {
		IStructuredSelection selection = (IStructuredSelection) viewer
				.getSelection();
		TamAsm[] datas = (TamAsm[]) selection.toList().toArray(
				new TamAsm[selection.size()]);
		for (TamAsm data : datas)
			System.err.println("Dragged data " + data);
		if (TamAsmTransfer.getInstance().isSupportedType(event.dataType)) {
			event.data = datas;
		}
	}

}
