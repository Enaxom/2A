package itam.tamasmview.action;

import itam.Activator;
import itam.tam.TamException;
import itam.tamasmview.AsmView;
import itam.tamasmview.Messages;

import org.eclipse.jface.action.Action;

public class ReinitAction extends Action {
	private AsmView fPart;

	public ReinitAction(AsmView part) {
		super(Messages.getString("ReinitAction.Reinit")); //$NON-NLS-1$
		fPart = part;
		setImageDescriptor(Activator.getImageDescriptor("icons/reset.gif")); //$NON-NLS-1$
	}

	public void run() {
		try {
			Activator.getDefault().getController().resetAll();
		} catch (TamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
