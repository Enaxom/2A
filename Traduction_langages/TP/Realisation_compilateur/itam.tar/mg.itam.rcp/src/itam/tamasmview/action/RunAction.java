package itam.tamasmview.action;

import itam.Activator;
import itam.tamasmview.Messages;

import org.eclipse.jface.action.Action;

public class RunAction extends Action {

	public RunAction() {
		super(Messages.getString("RunAction.Run")); //$NON-NLS-1$
		setImageDescriptor(Activator.getImageDescriptor("icons/resume_co.gif")); //$NON-NLS-1$

	}

	public void run() {
		Activator.getDefault().getController().run();

	}
}
