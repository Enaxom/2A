package itam.tamasmview.action;

import itam.Activator;
import itam.tamasmview.Messages;

import org.eclipse.jface.action.Action;

public class StepAction extends Action {
	public StepAction() {
		super(Messages.getString("StepAction.Step_Into")); //$NON-NLS-1$
		setImageDescriptor(Activator
				.getImageDescriptor("icons/stepinto_co.gif")); //$NON-NLS-1$

	}

	public void run() {
		Activator.getDefault().getController().step();
	}
}
