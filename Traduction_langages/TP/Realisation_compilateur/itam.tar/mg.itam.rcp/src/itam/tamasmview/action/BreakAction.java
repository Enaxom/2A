package itam.tamasmview.action;

import itam.Activator;
import itam.tamasmview.Messages;

import org.eclipse.jface.action.Action;

public class BreakAction extends Action {
	public BreakAction() {
		super(Messages.getString("BreakAction.Set_Breakpoint")); //$NON-NLS-1$
		setImageDescriptor(Activator.getImageDescriptor("icons/import_wiz.gif")); //$NON-NLS-1$
	}

	public void run() {
		// Activator.getDefault().getController().setBreakpoint();
	}
}
