package itam.tamasmview;

import itam.Activator;
import itam.dataviewer.AbstractCellModifier;
import itam.dataviewer.AbstractDataViewer;

import org.eclipse.swt.widgets.TableItem;

/**
 * This class implements an ICellModifierExtension An ICellModifierExtension is
 * called when the user modifes a cell in the tableViewer
 */

public class TamAsmCellModifier extends AbstractCellModifier<TamAsm> {
	public TamAsmCellModifier(AbstractDataViewer<TamAsm> tableViewer) {
		super(tableViewer);
	}

	public Object getValue(Object element, String property) {
		int columnIndex = columnNames.indexOf(property);

		Object result = null;
		TamAsm data = (TamAsm) element;
		switch (columnIndex) {
		case 0:
			result = "" + data.getAdresse();
			break;
		case 1:
			result = "" + data.getEtiquette();
			break;
		case 2:
			result = "" + data.getInstruction();
			break;
		default:
			result = "";
		}
		return result;
	}

	/**
	 * @see org.eclipse.jface.viewers.ICellModifier#modify(java.lang.Object,
	 *      java.lang.String, java.lang.Object)
	 */
	public void modify(Object element, String property, Object value) {
		int columnIndex = columnNames.indexOf(property);
		TableItem item = (TableItem) element;
		TamAsm data = (TamAsm) item.getData();
		// System.err.println("modify TamAsm = " + data);
		String valueString;
		switch (columnIndex) {
		case 0:
			// valueString = ((String) value).trim();
			// data.setAdresse(Integer.parseInt(valueString));
			break;
		case 1:
			valueString = ((String) value).trim();
			if (!valueString.equals(data.getEtiquette())) {
				data.setEtiquette(valueString);
				Activator.getDefault().getController().updateCode(data);
			}
			break;
		case 2:
			valueString = ((String) value).trim();
			if (!valueString.equals(data.getInstruction())) {
				data.setInstruction(valueString);
				Activator.getDefault().getController().updateCode(data);
			}
			break;
		case 3:
		default:
		}
	}
}
