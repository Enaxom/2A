package itam.tamasmview.action;

import itam.tamasmview.AsmView;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.actions.ActionGroup;

public class TamAsmActionGroup extends ActionGroup {
	private AsmView fPart;
	private Action fLoadAction;
	private Action fAssembleAction;
	private Action fRunAction;
	private Action fResetAction;
	private Action fStepAction;
	private Action fNextAction;

	// private BreakAction fBreakAction;
	private UnbreakAllAction fUnbreakAction;
//	private ReinitAction fReinitAction;

	public TamAsmActionGroup(AsmView part) {
		super();
		fPart = part;
		fLoadAction = new ImportAction(fPart);
		fAssembleAction = new ExportAction(fPart);
		fRunAction = new RunAction();
		fResetAction = new StopAction();
		fStepAction = new StepAction();
		fNextAction = new NextAction();
		// fBreakAction = new BreakAction();
		fUnbreakAction = new UnbreakAllAction();
//		fReinitAction = new ReinitAction(fPart);
	}

	public void fillActionBars(IActionBars actionBars) {
		super.fillActionBars(actionBars);
		actionBars.getToolBarManager().removeAll();
		actionBars.getMenuManager().removeAll();
		fillToolBar(actionBars.getToolBarManager());
		actionBars.updateActionBars();
	}

	void fillToolBar(IToolBarManager toolBar) {
		toolBar.add(fLoadAction);
		toolBar.add(fAssembleAction);
		// toolBar.add(fBreakAction);
		toolBar.add(fRunAction);
		toolBar.add(fResetAction);
		toolBar.add(fNextAction);
		toolBar.add(fStepAction);
		toolBar.add(fUnbreakAction);
//		toolBar.add(fReinitAction);
	}

	void updateActionBars(IActionBars actionBars) {
		actionBars.getToolBarManager().removeAll();
		actionBars.getMenuManager().removeAll();
		actionBars.updateActionBars();
	}
}
