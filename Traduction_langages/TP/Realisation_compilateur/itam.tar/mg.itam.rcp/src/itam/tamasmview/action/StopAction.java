package itam.tamasmview.action;

import itam.Activator;
import itam.tamasmview.Messages;

import org.eclipse.jface.action.Action;

public class StopAction extends Action {
	public StopAction() {
		super(Messages.getString("StopAction.Stop")); //$NON-NLS-1$
		setImageDescriptor(Activator
				.getImageDescriptor("icons/terminatedlaunch_obj.gif")); //$NON-NLS-1$

	}

	public void run() {
		Activator.getDefault().getController().stop();
	}
}
