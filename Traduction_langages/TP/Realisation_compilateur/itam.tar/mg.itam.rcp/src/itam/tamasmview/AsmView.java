package itam.tamasmview;

import itam.Activator;
import itam.Controller;
import itam.Messages;
import itam.dataviewer.DataList;
import itam.tamasmview.action.TamAsmActionGroup;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.ViewForm;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.part.PageBook;
import org.eclipse.ui.part.ViewPart;

public class AsmView extends ViewPart {

	public static final String ID = "mg.itam.rcp.asmView"; //$NON-NLS-1$
	private TamAsmViewer tableTamAsmViewer;
	private PageBook fPagebook;
	private Label fNoViewShownLabel;

	private SashForm fTamAsmSplitter;

	private ViewForm fTamAsmViewerViewForm;
	private CLabel fTamAsmViewerPaneLabel;

	private TamAsmActionGroup fActionSet;

	public AsmView() {
	}

	public void createPartControl(Composite parent) {
		fPagebook = new PageBook(parent, SWT.NONE);
		// page 1 of page book (no hierarchy label)

		fNoViewShownLabel = new Label(fPagebook, SWT.TOP + SWT.LEFT + SWT.WRAP);
		fNoViewShownLabel.setText(Messages.getString("AsmView.Empty")); //$NON-NLS-1$
		fTamAsmSplitter = new SashForm(fPagebook, SWT.HORIZONTAL);
		fTamAsmSplitter.setVisible(false);
		fTamAsmViewerViewForm = new ViewForm(fTamAsmSplitter, SWT.NONE);
		Control asmViewerControl = createTamAsmViewer(fTamAsmViewerViewForm);
		fTamAsmViewerViewForm.setContent(asmViewerControl);
		fTamAsmViewerPaneLabel = new CLabel(fTamAsmViewerViewForm, SWT.NONE);
		fTamAsmViewerPaneLabel.setText(""); //$NON-NLS-1$
		// fTamAsmViewerViewForm.setTopLeft(fTamAsmViewerPaneLabel);
		// ToolBar ViewerToolBar = new ToolBar(fTamAsmViewerViewForm, SWT.FLAT
		// | SWT.WRAP);
		// fTamAsmViewerViewForm.setTopCenter(ViewerToolBar);

		fTamAsmSplitter.setWeights(new int[] { 100 });
		makeActions(); // call before registering for selection changes
		fillActionBars();
		fPagebook.showPage(fTamAsmSplitter);
	}

	private Control createTamAsmViewer(Composite parent) {
		final Controller controller = Activator.getDefault().getController();
		final DataList<TamAsm> dl = controller.getTamAsmDataList();
		tableTamAsmViewer = new TamAsmViewer(parent, dl);
		tableTamAsmViewer.setEditable(true);
		final Table table = tableTamAsmViewer.getTable();
		Menu menu = new Menu(table.getShell(), SWT.POP_UP);
		MenuItem item = new MenuItem(menu, SWT.PUSH);
		item.setText(Messages.getString("AsmView.Toggle_BreakPoint")); //$NON-NLS-1$
		item.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event e) {
				int tis[] = table.getSelectionIndices();
				for (int t : tis) {
					controller.toggleBreakpoint(t);
				}
			}
		});
		table.setMenu(menu);
		return table;
	}

	public void setFocus() {
		fPagebook.setFocus();
	}

	public void dispose() {
		if (fActionSet != null)
			fActionSet.dispose();
		super.dispose();

	}

	private void makeActions() {
		fActionSet = new TamAsmActionGroup(this);
	}

	private void fillActionBars() {
		IActionBars actionBars = getViewSite().getActionBars();
		fActionSet.fillActionBars(actionBars);
		fActionSet.updateActionBars();
	}

}
