package itam.tamasmview.action;

import itam.Activator;
import itam.tamasmview.Messages;

import org.eclipse.jface.action.Action;

public class NextAction extends Action {
	public NextAction() {
		super(Messages.getString("NextAction.Step_Over")); //$NON-NLS-1$
		setImageDescriptor(Activator
				.getImageDescriptor("icons/stepover_co.gif")); //$NON-NLS-1$

	}

	public void run() {
		Activator.getDefault().getController().next();
	}
}
