package itam.tamasmview;

import itam.dataviewer.Data;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class TamAsm extends Data {
	private int adresse;
	private String etiquette;
	private String instruction;
	private boolean bp;
	private boolean cp;

	public TamAsm(int adresse, String etiquette, String instruction,
			boolean bp, boolean cp) {
		super("asm");
		this.adresse = adresse;
		this.etiquette = etiquette;
		this.instruction = instruction;
		this.bp = bp;
		this.cp = cp;
	}

	public TamAsm(DataInputStream dataIn) {
		super(dataIn);
		try {
			this.adresse = dataIn.readInt();
			this.etiquette = dataIn.readUTF();
			this.instruction = dataIn.readUTF();
			this.bp = dataIn.readBoolean();
			this.cp = dataIn.readBoolean();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean equals(Object object) {
		if (!(object instanceof TamAsm))
			return false;
		if (this == object)
			return true;
		TamAsm data = ((TamAsm) object);
		return adresse == data.adresse;
	}

	public void writeData(DataOutputStream dataOut) throws IOException {
		super.writeData(dataOut);
		dataOut.writeInt(adresse);
		dataOut.writeUTF(etiquette);
		dataOut.writeUTF(instruction);
		dataOut.writeBoolean(bp);
		dataOut.writeBoolean(cp);

	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(adresse + ", " + etiquette + " , " + instruction + ", " + bp
				+ ", " + cp);
		return sb.toString();
	}

	public int getAdresse() {
		return adresse;
	}

	public void setAdresse(int adresse) {
		this.adresse = adresse;
	}

	public String getEtiquette() {
		return etiquette;
	}

	public void setEtiquette(String etiquette) {
		this.etiquette = etiquette;
	}

	public String getInstruction() {
		return instruction;
	}

	public void setInstruction(String instruction) {
		this.instruction = instruction;
	}

	public boolean isBp() {
		return bp;
	}

	public void setBp(boolean bp) {
		this.bp = bp;
	}

	public boolean isCp() {
		return cp;
	}

	public void setCp(boolean cp) {
		this.cp = cp;
	}

}
