package itam.tamasmview;

import itam.dataviewer.AbstractEditDataViewer;
import itam.dataviewer.DataList;
import itam.dataviewer.DelDropAdapter;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.IBaseLabelProvider;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class TamAsmViewer extends AbstractEditDataViewer<TamAsm> {

	public TamAsmViewer(Composite parent, DataList<TamAsm> dl) {
		super(parent, dl);
	}

	@Override
	protected void setupCellModifier() {
		cellModifier = new TamAsmCellModifier(this);

	}

	@Override
	protected void setupCellEditors(CellEditor[] editors) {
		TextCellEditor textEditor = new TextCellEditor(table);
		((Text) textEditor.getControl()).setTextLimit(60);
		// pas l'adresse
		for (int i = 1; i < 3; i++)
			editors[i] = textEditor;
	}

	@Override
	protected IBaseLabelProvider setupLabelProvider() {
		return new TamAsmLabelProvider();
	}

	@Override
	protected void showInfo(int t, Shell shell) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void setupDropAdapter() {
		ops = DND.DROP_COPY | DND.DROP_MOVE;
		dropTransfers = new Transfer[] { TamAsmTransfer.getInstance(),
				FileTransfer.getInstance() };
		dropAdapter = new TamAsmDropAdapter(tableViewer);
	}

	@Override
	protected void setupDragListener() {
		ops = DND.DROP_COPY | DND.DROP_MOVE;
		dragTransfers = new Transfer[] { TamAsmTransfer.getInstance() };
		dragListener = new TamAsmDragListener(tableViewer);
	}

	@Override
	protected void setupDelListener() {
		delTransfer = TamAsmTransfer.getInstance();
		delListener = new DelDropAdapter<TamAsm>(this, delTransfer);
	}
}
