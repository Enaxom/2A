package itam.tamasmview.action;

import itam.Activator;
import itam.tamasmview.Messages;

import org.eclipse.jface.action.Action;

public class UnbreakAllAction extends Action {

	public UnbreakAllAction() {
		super(Messages.getString("UnbreakAllAction.Remove_All_BreakPoints")); //$NON-NLS-1$
		setImageDescriptor(Activator.getImageDescriptor("icons/remall.gif")); //$NON-NLS-1$
	}

	public void run() {
		Activator.getDefault().getController().unBreakAll();
	}
}
