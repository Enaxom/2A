package itam.tamasmview;

import itam.Activator;
import itam.Controller;
import itam.dataviewer.DataViewerDropAdapter;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.dnd.TransferData;

public class TamAsmDropAdapter extends DataViewerDropAdapter {
	private TransferData type;
	private int op;

	protected TamAsmDropAdapter(TableViewer viewer) {
		super(viewer);
		// TODO Auto-generated constructor stub
	}

	public boolean validateDrop(Object target, int op, TransferData type) {
		this.type = type;
		this.op = op;
		return TamAsmTransfer.getInstance().isSupportedType(type)
				|| FileTransfer.getInstance().isSupportedType(type);
	}

	public boolean performDrop(Object data) {
		Controller controller = Activator.getDefault().getController();
		if (FileTransfer.getInstance().isSupportedType(type)) {
			// TamAsm target = (TamAsm) getCurrentTarget();
			String[] datas = (String[]) data;
			String fname = datas[0];
			controller.importFile(fname);
			return true;
		}
		if (TamAsmTransfer.getInstance().isSupportedType(type)) {
			System.err.println("op = " + op);
			TamAsm[] datas = (TamAsm[]) data;
			TamAsm target = (TamAsm) getCurrentTarget();
			// il faut bien viser dans la table...
			// System.out.println("Target = " + target);
			if (target == null) {// new datas � la fin
				switch (op) {
				case DND.DROP_COPY:
					controller.copyCode(datas);
					break;
				case DND.DROP_MOVE:
					controller.moveCode(datas);
					break;
				default:
					break;
				}
				return true;
			}
			// insert datas
			if (op == DND.DROP_COPY) {
				switch (op) {
				case DND.DROP_COPY:
					controller.copyCode(target.getAdresse(), datas);
					break;
				case DND.DROP_MOVE:
					controller.moveCode(target.getAdresse(), datas);
					break;
				default:
					break;
				}
				return true;
			}

		}
		return false;
	}
}
