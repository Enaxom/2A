package itam.tamasmview.action;

import itam.Activator;
import itam.tamasmview.AsmView;
import itam.tamasmview.Messages;

import org.eclipse.jface.action.Action;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;

public class ExportAction extends Action {
	private AsmView fPart;

	public ExportAction(AsmView part) {
		super(Messages.getString("ExportAction.Export")); //$NON-NLS-1$
		fPart = part;
		setImageDescriptor(Activator.getImageDescriptor("icons/export_wiz.gif")); //$NON-NLS-1$

	}

	public void run() {
		FileDialog dialog = new FileDialog(fPart.getSite().getShell(), SWT.SAVE);
		dialog.setText(Messages.getString("ExportAction.Export_File")); //$NON-NLS-1$
		dialog.setFilterNames(new String[] { Messages
				.getString("ExportAction.Tam_Source") }); //$NON-NLS-1$
		dialog.setFilterExtensions(new String[] { "*.tam" }); //$NON-NLS-1$
		String fname = dialog.open();
		if (fname == null)
			System.err
					.println(Messages.getString("ExportAction.Export_Cancel")); //$NON-NLS-1$
		else {
			Activator.getDefault().getController().exportFile(fname);
		}
	}
}
