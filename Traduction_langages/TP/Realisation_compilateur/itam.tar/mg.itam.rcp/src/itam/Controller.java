package itam;

import itam.dataviewer.DataList;
import itam.heapview.Heap;
import itam.heapview.HeapDataList;
import itam.stackview.Stack;
import itam.stackview.StackDataList;
import itam.tam.Machine;
import itam.tam.TamException;
import itam.tamasmview.TamAsm;
import itam.tamasmview.TamAsmDataList;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Vector;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.IOConsole;
import org.eclipse.ui.console.IOConsoleOutputStream;

public class Controller {
	private DataList<TamAsm> tamAsmDataList;

	private DataList<Stack> stackDataList;

	private DataList<Heap> heapDataList;

	private Machine fMachine;

	private int oldCP;

	private int oldST;

	private int oldHT;

	private int oldLB;

	private String fName;
	private boolean fModified;
	private IOConsole ioconsole;

	private boolean editable;

	public Controller() {
		ioconsole = new IOConsole(
				Messages.getString("Controller.Title"), Activator //$NON-NLS-1$
						.getImageDescriptor("icons/console_view.gif")); //$NON-NLS-1$
		ConsolePlugin.getDefault().getConsoleManager().addConsoles(
				new IConsole[] { ioconsole });
		// IOConsoleInputStream iocin = ioconsole.getInputStream();
		// System.setIn(iocin);
		IOConsoleOutputStream iocout = ioconsole.newOutputStream();
		System.setOut(new PrintStream(iocout));
		// iocout.setColor());
		IOConsoleOutputStream iocerr = ioconsole.newOutputStream();
		System.setErr(new PrintStream(iocerr));
		System.err.println(Messages.getString("Controller.Welcome")); //$NON-NLS-1$
		fMachine = new Machine();
		tamAsmDataList = new TamAsmDataList();
		stackDataList = new StackDataList();
		heapDataList = new HeapDataList();
		oldCP = fMachine.getCB();
		oldLB = fMachine.getSB();
		oldST = fMachine.getSB();
		oldHT = fMachine.getHB();
		fName = null;
		fModified = false;
		stop();
	}

	public DataList<TamAsm> getTamAsmDataList() {
		return tamAsmDataList;
	}

	public DataList<Stack> getStackDataList() {
		return stackDataList;
	}

	public DataList<Heap> getHeapDataList() {
		return heapDataList;
	}

	public Machine getMachine() {
		return fMachine;
	}

	public void update() {
		updateCP();
		updateStack();
		updateHeap();
	}

	private void updateHeap() {
		Heap data = null;
		Vector<Heap> datas = heapDataList.getDatas();
		int[] valeurs = fMachine.getData();
		int ht = fMachine.getHT();
		int hb = fMachine.getHB();
		// System.err.println(" oldST = " + oldST + " st " + st);
		if (ht != hb - oldHT) {
			int top = datas.size();
			if (ht >= top) {
				for (int i = top; i <= ht; i++) {
					// System.err.println("add : i " + i + " : " + valeurs[i]);
					data = new Heap(hb - i, valeurs[i], false);
					heapDataList.addData(data);
				}
			}
			// update oldht
			data = datas.elementAt(oldHT);
			// data.setValeur(valeurs[hb -oldHT]);
			data.setHt(false);
			heapDataList.updateData(data);
			// set ht
			data = datas.elementAt(ht);
			data.setHt(true);
			// System.err.println("update st : " + ht + " " + data.getValeur()
			// + " / " + valeurs[st]);
			heapDataList.updateData(data);
			// update
			for (int i = 0; i < ht; i++) {
				data = datas.elementAt(i);
				// System.err.println("update i : " + i + " " + data.getValeur()
				// + " / " + valeurs[i]);
				if (data.getValeur() != valeurs[hb - i]) {
					data.setValeur(valeurs[hb - i]);
					heapDataList.updateData(data);
				}
			}
		}
		oldHT = ht;
	}

	private void updateStack() {
		Stack data = null;
		Vector<Stack> datas = stackDataList.getDatas();
		int[] valeurs = fMachine.getData();
		int st = fMachine.getST();
		int lb = fMachine.getLB();
		// System.err.println(" oldST = " + oldST + " st " + st);
		if (st != oldST) {
			int top = datas.size();
			if (st >= top) {
				for (int i = top; i <= st; i++) {
					// System.err.println("add : i " + i + " : " + valeurs[i]);
					data = new Stack(i, valeurs[i], false, false, ""); //$NON-NLS-1$
					stackDataList.addData(data);
				}
			}
			// update oldst
			data = datas.elementAt(oldST);
			// data.setValeur(valeurs[oldST]);
			data.setSt(false);
			stackDataList.updateData(data);
			// set st
			data = datas.elementAt(st);
			data.setSt(true);
			// System.err.println("update st : " + st + " " + data.getValeur()
			// + " / " + valeurs[st]);
			stackDataList.updateData(data);
			// update
			for (int i = 0; i < st; i++) {
				data = datas.elementAt(i);
				// System.err.println("update i : " + i + " " + data.getValeur()
				// + " / " + valeurs[i]);
				if (data.getValeur() != valeurs[i]) {
					data.setValeur(valeurs[i]);
					stackDataList.updateData(data);
				}
			}
		}
		oldST = st;
		if (lb > oldLB) {
			data = datas.elementAt(oldLB);
			// data.setInfo("");
			data.setLb(false);
			stackDataList.updateData(data);
			data = datas.elementAt(lb);
			data.setInfo(fMachine.getFunName());
			data.setLb(true);
			stackDataList.updateData(data);
			oldLB = lb;
		} else if (lb < oldLB) {
			data = datas.elementAt(oldLB);
			data.setInfo(""); //$NON-NLS-1$
			data.setLb(false);
			stackDataList.updateData(data);
			data = datas.elementAt(lb);
			// data.setInfo("");
			data.setLb(true);
			stackDataList.updateData(data);
			oldLB = lb;
		}
	}

	private void updateCP() {
		int cp = fMachine.getCP();
		// System.err.println("CP = " + cp);
		TamAsm data;
		if (oldCP != cp) {
			data = tamAsmDataList.getDatas().elementAt(oldCP);
			data.setCp(false);
			tamAsmDataList.updateData(data);
		}

		if (tamAsmDataList.getDatas().size() != 0) {
			data = tamAsmDataList.getDatas().elementAt(cp);
			oldCP = cp;
			data.setCp(true);
			tamAsmDataList.updateData(data);
		}
	}

	private void resetMem() {
		oldST = 0;
		oldLB = 0;
		stackDataList.clearDatas();
		stackDataList.addData(new Stack(fMachine.getSB(), 0, true, true, "")); //$NON-NLS-1$

		oldHT = fMachine.getHB();
		heapDataList.clearDatas();
		heapDataList.addData(new Heap(fMachine.getHB(), 0, true));
		updateCP();
		oldCP = 0;
	}

	public void importFile(String fname) {
		// System.err.println("Importing file " + fname);
		try {
			ByteArrayOutputStream out = null;
			if (fname.endsWith(".tam")) { //$NON-NLS-1$
				out = Assembler.assembleFile(fname);
				fMachine.loadObjectProgram(out);
				setCode();
				fName = fname;
				fModified = false;
				editable = false;
			}
		} catch (TamException e) {
			System.err.println(e.getMessage());
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public void setCode() {
		// System.err.println("aMachine " + fMachine.getCT());
		tamAsmDataList.clearDatas();
		int ct = fMachine.getCT();
		for (int i = 0; i < ct; i++) {
			tamAsmDataList.addData(new TamAsm(i, fMachine.getLabel(i), fMachine
					.writeInst(i), false, false));
		}
		resetMem();
	}

	public void run() {
		try {
			fMachine.mrun();
			update();
		} catch (TamException e) {
			log(e.getMessage());
		}
	}

	public void next() {
		try {
			fMachine.mnext();
			update();
		} catch (TamException e) {
			log(e.getMessage());
		}
	}

	public void step() {
		try {
			fMachine.mstep();
			update();
		} catch (TamException e) {
			log(e.getMessage());
		}
	}

	public void stop() {
		try {
			fMachine.mreset();
			resetMem();
		} catch (TamException e) {
			log(e.getMessage());
		}
	}

	public void toggleBreakpoint(int i) {
		fMachine.toggleBreakPoint(i);
		TamAsm data = tamAsmDataList.getDatas().elementAt(i);
		data.setBp(fMachine.getCode()[i].isBreakpoint());
		tamAsmDataList.updateData(data);
	}

	public void updateCode(TamAsm data) {
		// System.err.println("modified TamAsm = " + data);
		tamAsmDataList.updateData(data);
		reAssemble();
		fModified = true;
	}

	public void copyCode(TamAsm[] datas) {
		for (TamAsm d : datas) {
			tamAsmDataList.addData(d);
		}
		reAssemble();
		fModified = true;
	}

	public void moveCode(TamAsm[] datas) {
		for (TamAsm d : datas) {
			tamAsmDataList.deleteData(d);
		}
		reAssemble();
	}

	public void copyCode(int adresse, TamAsm[] datas) {
		for (TamAsm d : datas) {
			tamAsmDataList.addData(adresse, d);
		}
		reAssemble();
	}

	public void moveCode(int adresse, TamAsm[] datas) {
		for (TamAsm d : datas) {
			tamAsmDataList.deleteData(d);
		}
		reAssemble();
	}

	private void reAssemble() {
		try {
			String code = getCodeFromTable();
			ByteArrayOutputStream out = Assembler.assembleString(code);
			fMachine.loadObjectProgram(out);
			setCode();
			fModified = true;
		} catch (TamException e) {
			log(e.getMessage());
		} catch (Exception e) {
			log(e.getMessage());
		}
	}

	private String getCodeFromTable() {
		StringBuffer sb = new StringBuffer();
		for (TamAsm data : tamAsmDataList.getDatas()) {
			if (!"".equals(data.getEtiquette())) //$NON-NLS-1$
				sb.append(data.getEtiquette() + "\n");//$NON-NLS-1$
			sb.append("\t" + data.getInstruction() + "\n"); //$NON-NLS-1$ //$NON-NLS-2$
		}
		return sb.toString();
	}

	public void unBreakAll() {
		for (int i = fMachine.getCB(); i < fMachine.getCT(); i++) {
			if (fMachine.isBreakPoint(i)) {
				fMachine.toggleBreakPoint(i);
				TamAsm data = tamAsmDataList.getDatas().elementAt(i);
				data.setBp(false);
				tamAsmDataList.updateData(data);
			}

		}
	}

	public void exportFile(String fname) {
		try {
			if (!fname.endsWith(".tam")) //$NON-NLS-1$
				fname += ".tam"; //$NON-NLS-1$
			FileWriter os = new FileWriter(new File(fname));
			os.write(getCodeFromTable());
			os.close();
		} catch (FileNotFoundException e) {
			log(e.getMessage());
		} catch (IOException e) {
			log(e.getMessage());
		}
	}

	private void log(String message) {
		System.err.println(message);
		MessageBox dialog = new MessageBox(Display.getDefault()
				.getActiveShell(), SWT.OK);
		dialog.setText(Messages.getString("Controller.Information")); //$NON-NLS-1$
		dialog.setMessage(message);
		dialog.open();
	}

	class InputDialog extends Dialog {
		protected int result;
		protected Shell shell;

		public InputDialog(Shell parent, int style) {
			super(parent, style);
			createContents();
		}

		public int open() {
			shell.open();
			shell.layout();
			Display display = getParent().getDisplay();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			return result;
		}

		protected void createContents() {
			shell = new Shell(getParent(), SWT.TITLE | SWT.BORDER);
			shell.setSize(200, 100);
			shell.setText(Messages.getString("Controller.Input")); //$NON-NLS-1$
			GridLayout btnLayout = new GridLayout();
			btnLayout.numColumns = 2;
			// btnLayout.makeColumnsEqualWidth = true;
			shell.setLayout(btnLayout);
			final Text text = new Text(shell, SWT.NONE);
			final Button okButton = new Button(shell, SWT.NONE);
			okButton.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent arg0) {
					String res = text.getText().trim();
					if (res == null || "".equals(res)) //$NON-NLS-1$
						return;
					result = Integer.parseInt(res);
					shell.close();
				}
			});
			okButton.setText(Messages.getString("Controller.OK")); //$NON-NLS-1$
			shell.pack();
		}

	}

	public int readInt() {
		InputDialog dialog = new InputDialog(Display.getDefault()
				.getActiveShell(), SWT.NONE);
		return dialog.open();
	}

	public void resetAll() throws TamException {
		tamAsmDataList.clearDatas();
		fMachine.mreset();
		resetMem();
	}

	public void setEditable() {
		editable = !editable;
	}
}
