package itam;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;

public class OpenViewAction extends Action {

	private final IWorkbenchWindow window;
	private final String viewId;

	public OpenViewAction(IWorkbenchWindow window, String label, String viewId) {
		this.window = window;
		this.viewId = viewId;
		setText(label);
		// The id is used to refer to the action in a menu or toolbar
		setId(ICommandIds.CMD_OPEN);
		// Associate the action with a pre-defined command, to allow key
		// bindings.
//		setActionDefinitionId(ICommandIds.CMD_OPEN);
		setImageDescriptor(itam.Activator
				.getImageDescriptor("/icons/sample2.gif")); //$NON-NLS-1$
	}

	public void run() {
		if (window != null) {
			try {
				window.getActivePage().showView(viewId);
			} catch (PartInitException e) {
				MessageDialog
						.openError(window.getShell(),
								Messages.getString("OpenViewAction.Error"), //$NON-NLS-1$
								Messages.getString("OpenViewAction.Open_Error") + e.getMessage()); //$NON-NLS-1$
			}
		}
	}
}
