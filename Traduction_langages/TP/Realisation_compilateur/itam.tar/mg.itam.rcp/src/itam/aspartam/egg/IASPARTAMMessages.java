package itam.aspartam.egg;
public interface IASPARTAMMessages {

  public static  int id_ASPARTAM_expected_token = 6160384;
  public static  int id_ASPARTAM_unexpected_token = 6160385;
  public static  int id_ASPARTAM_expected_eof = 6160386;
  public static  int id_R_INC = 6160387;
  public static  int id_S_INC = 6160388;
  public static  int id_L_ERR = 6160389;
  }
