package itam;

import itam.dataviewer.DataList;
import itam.heapview.Heap;
import itam.heapview.HeapViewer;
import itam.stackview.Stack;
import itam.stackview.StackViewer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.ViewForm;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.ui.part.PageBook;
import org.eclipse.ui.part.ViewPart;

public class TamView extends ViewPart {

	public static final String ID = "mg.itam.rcp.stackView"; //$NON-NLS-1$

	private final static int SNUM = 0;

	private final static int SVAL = 1;

	private final static int SST = 2;

	private final static int SLB = 3;

	private final static int SFUN = 4;

	private StackViewer tableStackViewer;
	private HeapViewer tableHeapViewer;

	private PageBook fPagebook;
	private PageBook fStackViewerbook;
	private PageBook fHeapViewerbook;
	private Label fNoViewShownLabel;

	private SashForm fStackHeapSplitter;

	private ViewForm fStackViewerViewForm;
	private CLabel fStackViewerPaneLabel;

	private ViewForm fHeapViewerViewForm;

	private CLabel fHeapViewerPaneLabel;

	public void createPartControl(Composite parent) {
		fPagebook = new PageBook(parent, SWT.NONE);
		// fWorkingSetActionGroup= new WorkingSetFilterActionGroup(getSite(),
		// fPropertyChangeListener);

		// page 1 of page book (no hierarchy label)

		fNoViewShownLabel = new Label(fPagebook, SWT.TOP + SWT.LEFT + SWT.WRAP);
		fNoViewShownLabel.setText(Messages.getString("TamView.Empty")); //$NON-NLS-1$

		// page 2 of page book (viewers)
		fStackHeapSplitter = new SashForm(fPagebook, SWT.HORIZONTAL);
		fStackHeapSplitter.setVisible(false);

		fStackViewerViewForm = new ViewForm(fStackHeapSplitter, SWT.NONE);
		Control stackViewerControl = createStackViewerControl(fStackViewerViewForm);
		fStackViewerViewForm.setContent(stackViewerControl);
		fStackViewerPaneLabel = new CLabel(fStackViewerViewForm, SWT.NONE);
		fStackViewerPaneLabel.setText(Messages.getString("TamView.Stack")); //$NON-NLS-1$
		fStackViewerViewForm.setTopLeft(fStackViewerPaneLabel);
		ToolBar StackViewerToolBar = new ToolBar(fStackViewerViewForm, SWT.FLAT
				| SWT.WRAP);
		fStackViewerViewForm.setTopCenter(StackViewerToolBar);

		fHeapViewerViewForm = new ViewForm(fStackHeapSplitter, SWT.NONE);
		Control heapViewerControl = createHeapViewerControl(fHeapViewerViewForm);
		fHeapViewerViewForm.setContent(heapViewerControl);
		fHeapViewerPaneLabel = new CLabel(fHeapViewerViewForm, SWT.NONE);
		fHeapViewerPaneLabel.setText(Messages.getString("TamView.Heap")); //$NON-NLS-1$
		fHeapViewerViewForm.setTopLeft(fHeapViewerPaneLabel);
		ToolBar HeapViewerToolBar = new ToolBar(fHeapViewerViewForm, SWT.FLAT
				| SWT.WRAP);
		fHeapViewerViewForm.setTopCenter(HeapViewerToolBar);

		fStackHeapSplitter.setWeights(new int[] { 50, 50 });

		fPagebook.showPage(fStackHeapSplitter);
	}

	private Control createStackViewerControl(Composite parent) {
		Controller controller = Activator.getDefault().getController();
		DataList<Stack> dl = controller.getStackDataList();
		tableStackViewer = new StackViewer(parent, dl);
		return tableStackViewer.getTable();
	}

	private Control createHeapViewerControl(Composite parent) {
		Controller controller = Activator.getDefault().getController();
		DataList<Heap> dl = controller.getHeapDataList();
		tableHeapViewer = new HeapViewer(parent, dl);
		return tableHeapViewer.getTable();
	}

	public void setFocus() {
		fPagebook.setFocus();
	}
}
