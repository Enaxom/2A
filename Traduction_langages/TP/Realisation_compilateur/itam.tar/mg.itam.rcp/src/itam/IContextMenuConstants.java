package itam;

public interface IContextMenuConstants {
	public static final String ASM_VIEW = Activator.PLUGIN_ID + ".asm";
}
