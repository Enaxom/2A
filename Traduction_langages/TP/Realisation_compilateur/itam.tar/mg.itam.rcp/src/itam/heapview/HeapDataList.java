package itam.heapview;

import itam.dataviewer.DataList;

public class HeapDataList extends DataList<Heap> {

	@Override
	public String[] getColumnNames() {
		return new String[] {
				Messages.getString("HeapDataList.0"), Messages.getString("HeapDataList.Value"), Messages.getString("HeapDataList.HT") }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
	}

	@Override
	public int[] getColumnTypes() {
		return null;
	}

	@Override
	public int[] getColumnWidths() {
		return new int[] { 100, 120, 40 };
	}

	@Override
	public int getColumnHeight() {
		// TODO Auto-generated method stub
		return 100;
	}

}
