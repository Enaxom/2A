package itam.heapview;

import itam.dataviewer.DataDragListener;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.swt.dnd.DragSourceEvent;

public class HeapDragListener extends DataDragListener {

	public HeapDragListener(StructuredViewer viewer) {
		super(viewer);
		// TODO Auto-generated constructor stub
	}

	public void dragSetData(DragSourceEvent event) {
		IStructuredSelection selection = (IStructuredSelection) viewer
				.getSelection();
		Heap[] datas = (Heap[]) selection.toList().toArray(
				new Heap[selection.size()]);
		if (HeapTransfer.getInstance().isSupportedType(event.dataType)) {
			event.data = datas;
		}
	}

}
