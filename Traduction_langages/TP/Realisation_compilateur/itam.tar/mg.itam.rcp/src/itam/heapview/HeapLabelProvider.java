package itam.heapview;

import itam.Activator;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

/**
 * Label provider for the TaskViewer
 * 
 * @see org.eclipse.jface.viewers.LabelProvider
 */
public class HeapLabelProvider extends LabelProvider implements
		ITableLabelProvider {

	// Names of icons used to represent checkboxes
	public static final String NO_IMAGE = "icons/no_image.gif"; //$NON-NLS-1$
	public static final String HT_IMAGE = "icons/ht.gif"; //$NON-NLS-1$

	private static final Image no_image = null;
	private static final Image ht_image = Activator
			.getImageDescriptor(HT_IMAGE).createImage();

	/**
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnText(java.lang.Object,
	 *      int)
	 */
	public String getColumnText(Object element, int columnIndex) {
		String result = ""; //$NON-NLS-1$
		Heap data = (Heap) element;
		switch (columnIndex) {
		case 0:
			result = data.getAdresse() + ""; //$NON-NLS-1$
			break;
		case 1:
			result = data.getValeur() + ""; //$NON-NLS-1$
			break;
		default:
			break;
		}
		return result;
	}

	/**
	 * @see org.eclipse.jface.viewers.ITableLabelProvider#getColumnImage(java.lang.Object,
	 *      int)
	 */
	public Image getColumnImage(Object element, int columnIndex) {
		Image result = no_image;
		Heap data = (Heap) element;
		switch (columnIndex) {
		case 2:
			if (data.isHt())
				result = ht_image;
			break;
		default:
			break;
		}
		return result;
	}
}
