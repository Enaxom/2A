package itam.heapview;

import itam.dataviewer.AbstractDataViewer;
import itam.dataviewer.DataList;

import org.eclipse.jface.viewers.IBaseLabelProvider;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;

public class HeapViewer extends AbstractDataViewer<Heap> {

	public HeapViewer(Composite parent, DataList<Heap> dl) {
		super(parent, dl);
	}

	// @Override
	// protected void setupCellModifier() {
	// cellModifier = new HeapCellModifier(this);
	// }
	//
	// @Override
	// protected void setupCellEditors(CellEditor[] editors) {
	// TextCellEditor textEditor = new TextCellEditor(table);
	// ((Text) textEditor.getControl()).setTextLimit(60);
	// for (int i = 0; i < 3; i++)
	// editors[i] = textEditor;
	// }

	@Override
	protected IBaseLabelProvider setupLabelProvider() {
		return new HeapLabelProvider();
	}

	@Override
	protected void showInfo(int t, Shell shell) {
		// TODO Auto-generated method stub

	}

	// @Override
	// protected void setupDropAdapter() {
	// ops = DND.DROP_COPY | DND.DROP_MOVE;
	// dropTransfers = new Transfer[] { HeapTransfer.getInstance() };
	// dropAdapter = new HeapDropAdapter(tableViewer);
	// }

	@Override
	protected void setupDragListener() {
		ops = DND.DROP_COPY | DND.DROP_MOVE;
		dragTransfers = new Transfer[] { HeapTransfer.getInstance() };
		dragListener = new HeapDragListener(tableViewer);
	}

	// @Override
	// protected void setupDelListener() {
	// delTransfer = HeapTransfer.getInstance();
	// delListener = new DelDropAdapter<Heap>(this, delTransfer);
	// }
}
