package itam.heapview;

import itam.dataviewer.Data;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Heap extends Data {
	private int adresse;

	private int valeur;

	private boolean ht;

	public Heap(int adresse, int valeur, boolean rg) {
		super("stack");
		this.adresse = adresse;
		this.valeur = valeur;
		this.ht = rg;
	}

	public Heap(DataInputStream dataIn) {
		super(dataIn);
		try {
			this.adresse = dataIn.readInt();
			this.valeur = dataIn.readInt();
			this.ht = dataIn.readBoolean();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean equals(Object object) {
		if (!(object instanceof Heap))
			return false;
		if (this == object)
			return true;
		Heap data = ((Heap) object);
		return adresse == data.adresse && valeur == data.valeur;
	}

	public void writeData(DataOutputStream dataOut) throws IOException {
		super.writeData(dataOut);
		dataOut.writeInt(adresse);
		dataOut.writeInt(valeur);
		dataOut.writeBoolean(ht);

	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(adresse + ", " + valeur + " , " + ht);
		return sb.toString();
	}

	public int getAdresse() {
		return adresse;
	}

	public void setAdresse(int adresse) {
		this.adresse = adresse;
	}

	public int getValeur() {
		return valeur;
	}

	public void setValeur(int valeur) {
		this.valeur = valeur;
	}

	public boolean isHt() {
		return ht;
	}

	public void setHt(boolean rg) {
		this.ht = rg;
	}

}
