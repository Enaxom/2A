package itam.heapview;

import itam.dataviewer.DataViewerDropAdapter;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.dnd.TransferData;

public class HeapDropAdapter extends DataViewerDropAdapter {

	protected HeapDropAdapter(TableViewer viewer) {
		super(viewer);
		// TODO Auto-generated constructor stub
	}

	public boolean validateDrop(Object target, int op, TransferData type) {
		return HeapTransfer.getInstance().isSupportedType(type);
	}

	public boolean performDrop(Object data) {
		System.out.println("perform drop = " + data);

		Heap target = (Heap) getCurrentTarget();
		// il faut bien viser dans la table...
		System.out.println("Target = " + target);
		if (target == null)
			return false;
		ISelection sel = getViewer().getSelection();
		System.out.println("Sel Target = " + sel);
		String[] datas = (String[]) data;
		for (String d : datas) {
			System.out.println("File dropped = " + d);
		}
		((HeapDataList) getViewer().getInput()).updateDbData(target);
		return true;
	}

}
