package itam.heapview;

import itam.dataviewer.AbstractCellModifier;
import itam.dataviewer.AbstractDataViewer;

import org.eclipse.swt.widgets.TableItem;

/**
 * This class implements an ICellModifierExtension An ICellModifierExtension is
 * called when the user modifes a cell in the tableViewer
 */

public class HeapCellModifier extends AbstractCellModifier<Heap> {
	public HeapCellModifier(AbstractDataViewer<Heap> tableViewer) {
		super(tableViewer);
	}

	public Object getValue(Object element, String property) {
		int columnIndex = columnNames.indexOf(property);

		Object result = null;
		Heap data = (Heap) element;
		switch (columnIndex) {
		case 0:
			result = "" + data.getAdresse();
			break;
		case 1:
			result = "" + data.getValeur();
			break;
		case 2:
			result = "" + data.isHt();
			break;
		default:
			result = "";
		}
		return result;
	}

	/**
	 * @see org.eclipse.jface.viewers.ICellModifier#modify(java.lang.Object,
	 *      java.lang.String, java.lang.Object)
	 */
	public void modify(Object element, String property, Object value) {
		int columnIndex = columnNames.indexOf(property);
		TableItem item = (TableItem) element;
		Heap data = (Heap) item.getData();
		System.err.println("modify Heap = " + data);
		String valueString;
		switch (columnIndex) {
		case 0:
			valueString = ((String) value).trim();
			data.setAdresse(Integer.parseInt(valueString));
			break;
		case 1:
			valueString = ((String) value).trim();
			int adresse = Integer.parseInt(valueString);
			if (adresse != data.getValeur()) {
				data.setAdresse(adresse);
				tableViewer.getDataList().updateDbData(data);
			}
			break;
		case 2:
			valueString = ((String) value).trim();
			boolean rg = Boolean.parseBoolean(valueString);
			if (rg != data.isHt()) {
				data.setHt(rg);
				tableViewer.getDataList().updateDbData(data);
			}
			break;
		default:
		}
	}
}
