package exception;

public class NoDeclarationException extends RuntimeException{
	
	public NoDeclarationException(int ligne,String m){
		super ("Ligne "+ligne+" : La variable "+m+" est utilisée sans avoir été déclarée.");
	}

}
