package exception;

public class TypeException extends RuntimeException{
	
	public TypeException(int ligne, String m){
		super ("Ligne "+ligne+" : "+m);
	}
}
