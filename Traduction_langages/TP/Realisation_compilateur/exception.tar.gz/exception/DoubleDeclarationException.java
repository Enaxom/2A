package exception;

public class DoubleDeclarationException extends RuntimeException{
	
	public DoubleDeclarationException(int ligne, String m){
		super ("Ligne "+ligne+" : La varible "+m+" est déclarée deux fois dans le même bloc.");
	}

}
