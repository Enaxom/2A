package exception;

public class OperationInterditeException extends RuntimeException{
	
	public OperationInterditeException(int ligne, String m){
		super ("Ligne "+ligne+" : "+m);
	}
}
