
package attributs;

/** Information associée à un symbole dans la table des symboles.
 *  Ceci n'est qu'une interface de marquage. 
 */
public interface Info {
	
}
