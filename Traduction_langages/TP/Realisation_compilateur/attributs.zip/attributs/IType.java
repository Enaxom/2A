package attributs;

public interface IType {

}
