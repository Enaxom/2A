% Objectif du programme lineaire P1 :
C = ...

% Contraintes du programme lineaire P1 :
A = ...
B = ...
Binf = ...

% Resolution du programme lineaire P1 :
[X,zmin] = linprog(...);

% Affichage du resultat :
fprintf('\nLa solution vaut (%.2f,%.2f)\n',X);
fprintf('La valeur maximale de l''objectif vaut %.2f\n\n',-zmin);